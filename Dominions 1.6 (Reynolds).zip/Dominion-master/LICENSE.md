## Sharing Dominions
As per the SYSOPDOC.DOM file

You are free to copy and distribute Dominions and it's subprograms
as long as the following conditions are met...

     1) No fee or purchase cost is charged.

     2) Any modifications made are noted in the Sysopdoc.Dom file by the
        person making the modifications with the date and nature of the
        modifications.

     3) All programs listed in Section IV are included in the archive.

## Legal Stuff
The author of Dominions! assumes no responsibilty for any failure of
the program (or subprograms) to perform in the indicated or expressed way,
and/or any damage caused by the failure of the program.  Use Dominons!
at your own risk!
